export class Ghe{
    public SoGhe:number;
    public Gia:number;
    public TrangThai:boolean;
    constructor(){

    }
}